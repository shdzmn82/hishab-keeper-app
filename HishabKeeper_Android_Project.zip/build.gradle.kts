buildscript {
    ext.set("kotlin_version", "1.9.0")
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath("com.android.tools.build:gradle:8.1.0")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.0")
    }
}
task("clean", type: Delete::class) {
    delete(rootProject.buildDir)
}