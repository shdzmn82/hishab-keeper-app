package com.example.hishabkeeper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DashboardScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen() {
    val features = listOf(
        "১. একাধিক হিসাবখাতা (ব্যক্তিগত, স্কুল, কোচিং)",
        "২. আয়-ব্যয় ও ভাউচার আপলোড",
        "৩. শিক্ষার্থীর ফি ম্যানেজমেন্ট",
        "৪. ধার ও পাওনা ট্র্যাকিং",
        "৫. বাজেট ও ব্যয় সংকোচন",
        "৬. রিপোর্ট (PDF/CSV) ও এক্সপোর্ট",
        "৭. ডেটা ব্যাকআপ ও পিন সিকিউরিটি"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("হিসাব খাতা (Hishab Keeper)") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                )
            )
        }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues).padding(16.dp)) {
            Text(
                text = "অ্যাপের প্রস্তাবিত মডিউলসমূহ:",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            LazyColumn {
                items(features) { feature ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Text(
                            text = feature,
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
}